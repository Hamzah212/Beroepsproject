document.getElementById('reservationForm').addEventListener('submit', function(event) {
    event.preventDefault();
    
    // Get form values
    const rentalStartTime = document.getElementById('rentalStartTime').value;
    const rentalBikes = parseInt(document.getElementById('rentalBikes').value, 10);
    const tourTime = document.getElementById('tourTime').value;
    const tourParticipants = parseInt(document.getElementById('tourParticipants').value, 10);

    // Calculate total cost
    const rentalCost = rentalBikes * 15;
    const tourCost = tourParticipants * 10;
    const totalCost = rentalCost + tourCost;

    // Create reservation object
    const reservation = {
        rentalStartTime: rentalStartTime,
        rentalBikes: rentalBikes,
        tourTime: tourTime,
        tourParticipants: tourParticipants,
        totalCost: totalCost
    };

    // Save reservation to localStorage
    let reservations = JSON.parse(localStorage.getItem('reservations')) || [];
    reservations.push(reservation);
    localStorage.setItem('reservations', JSON.stringify(reservations));

    // Redirect to card.html to display the results
    window.location.href = 'card.html';
});
