// Functie om de reserveringen in de tabel te laden
function loadReservations() {
    const tableBody = document.querySelector('#reservationsTable tbody');
    tableBody.innerHTML = '';
    
    let reservations = JSON.parse(localStorage.getItem('reservations')) || [];
    
    reservations.forEach((reservation, index) => {
        const row = document.createElement('tr');
        
        row.innerHTML = `
            <td>${reservation.rentalStartTime}</td>
            <td>${reservation.rentalBikes}</td>
            <td>${reservation.tourTime}</td>
            <td>${reservation.tourParticipants}</td>
            <td>€${reservation.totalCost}</td>
            <td>
                <button onclick="editReservation(${index})">Wijzigen</button>
                <button onclick="deleteReservation(${index})">Verwijderen</button>
            </td>
        `;
        
        tableBody.appendChild(row);
    });
}

// Functie om een reservering te verwijderen
function deleteReservation(index) {
    let reservations = JSON.parse(localStorage.getItem('reservations')) || [];
    reservations.splice(index, 1);
    localStorage.setItem('reservations', JSON.stringify(reservations));
    loadReservations();
}

// Functie om een reservering te bewerken
function editReservation(index) {
    let reservations = JSON.parse(localStorage.getItem('reservations')) || [];
    const reservation = reservations[index];
    
    const newRentalStartTime = prompt("Starttijd Verhuur:", reservation.rentalStartTime);
    const newRentalBikes = prompt("Aantal Fietsen:", reservation.rentalBikes);
    const newTourTime = prompt("Tourtijd:", reservation.tourTime);
    const newTourParticipants = prompt("Deelnemers Tour:", reservation.tourParticipants);

    if (newRentalStartTime && newRentalBikes && newTourTime && newTourParticipants) {
        reservation.rentalStartTime = newRentalStartTime;
        reservation.rentalBikes = parseInt(newRentalBikes, 10);
        reservation.tourTime = newTourTime;
        reservation.tourParticipants = parseInt(newTourParticipants, 10);
        reservation.totalCost = (reservation.rentalBikes * 15) + (reservation.tourParticipants * 10);
        reservations[index] = reservation;
        localStorage.setItem('reservations', JSON.stringify(reservations));
        loadReservations();
    }
}

// Laad reserveringen bij het openen van de pagina
document.addEventListener('DOMContentLoaded', loadReservations);
